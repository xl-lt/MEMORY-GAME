/**
 * Author: Najah.
 * GitHub: xl-lt
 * linkedin: www.linkedin.com/in/najah-salem-sa
 * Project: http://www.abqrah.com
 */
MemoryGame.Card = function(value, isMatchingCard) {
  this.value = value;
  this.isRevealed = false;
  if (isMatchingCard) {
    this.isMatchingCard = true;
  }

  this.reveal = function() {
    this.isRevealed = true;
  }

  this.conceal = function() {
    this.isRevealed = false;
  }
};
